package exhodus.demo.enums;

public enum Difficulty {
    EASY,MEDUIM,HARD
}
