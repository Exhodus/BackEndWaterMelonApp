package exhodus.demo.enums;

public enum MaterialTypes {
    THREAD, HOOK, ACCESSORY, CLIP
}
